package com.campusfp.Escribir_JSON;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class EscribirJSON {

	public static void main(String[] args) throws IOException {
		List<Object> Objetos = new ArrayList<Object>();
		JSONArray ListaObjetos = new JSONArray();
		
		//primer item
				JSONObject obj1 = new JSONObject();
				
				obj1.put("Titulo", "Escribir JSON");
				obj1.put("Autor", "Javier");
				obj1.put("date", "January 2009");
				obj1.put("Nombre", "Pepe");
				obj1.put("Ciudad", "Madrid");
				obj1.put("Salario", "1500");
				
				JSONObject item1 = new JSONObject();
				item1.put("Item", obj1);
				
				ListaObjetos.add(item1);
				
				JSONObject obj2 = new JSONObject();
				obj2.put("Titulo", "Escribir JSON");
				obj2.put("Autor", "Javier");
				obj2.put("date", "February 2009");
				obj2.put("Nombre", "Juan");
				obj2.put("Ciudad", "Segovia");
				obj2.put("Salario", "1200");
				
				JSONObject item2 = new JSONObject();
				item2.put("Item", obj2);
				
				ListaObjetos.add(item2);
				
				JSONObject obj3 = new JSONObject();
				obj3.put("Titulo", "Escribir JSON");
				obj3.put("Autor", "Javier");;
				obj3.put("date", "December 2009");
				obj3.put("Nombre", "Ruth");
				obj3.put("Ciudad", "Madrid");
				obj3.put("Salario", "1850");
				
				JSONObject item3 = new JSONObject();
				item3.put("Item", obj3);
				
				ListaObjetos.add(item3);
				
		
		//Write JSON file
        try  {
        	
        	File file = new File("archivo.json");
        	
        	if(!file.exists()) {
				 file.createNewFile();
			}
        	
        	FileWriter fw = new FileWriter(file);
			
            BufferedWriter bw = new BufferedWriter(fw);
 
            fw.write(ListaObjetos.toJSONString());
            fw.flush();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
			
	}
	
}
