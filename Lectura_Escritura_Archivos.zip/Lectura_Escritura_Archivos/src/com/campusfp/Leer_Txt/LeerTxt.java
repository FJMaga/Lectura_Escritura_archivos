package com.campusfp.Leer_Txt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LeerTxt {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File archivo = new File ("archivo.txt");
		FileReader fr = new FileReader (archivo);
		BufferedReader br = new BufferedReader(fr);
		
		String linea = br.readLine();
		
		System.out.println(linea);
	}

}