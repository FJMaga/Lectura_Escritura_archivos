package com.campusfp.lecturaXML;

import java.util.List;

import com.campusfp.modelo.Item;

public class PruebaLeer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaXParser parsearLectura = new StaXParser();
		//parsearLectura.leer("config.xml"); //comprobacion de lectura
		List<Item> solucion = parsearLectura.leer("config.xml");
		List<Item> solucionEscritura = parsearLectura.leer("config2.xml");
		//System.out.println(solucion);
		System.out.println("######################################");
		for (Item item: solucion) {
			System.out.println(item);
        }
		for (Item itemEscritos: solucionEscritura) {
            System.out.println(itemEscritos);
		}
		
	}

}
