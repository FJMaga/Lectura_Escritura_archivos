package com.campusfp.escrituraXML;

public class PruebaEscribir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaXEscritura configFile = new StaXEscritura();
        configFile.setFile("config2.xml");
        try {
            configFile.saveConfig();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
