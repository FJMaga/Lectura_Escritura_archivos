package com.campusfp.Leer_JSON;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class LeerJSON {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
         
        try (FileReader reader = new FileReader("archivo.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);
 
            JSONArray ListaObjetos = (JSONArray) obj;
            System.out.println(ListaObjetos);
             
            //Iterate over items array
            
            ListaObjetos.forEach( ite -> parseEmployeeObject( (JSONObject) ite ) );
            
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
 
    private static void parseEmployeeObject(JSONObject ite) {
    	
    	System.out.println("################################");
    	
    	//cogemos los valores del listado de objetos
    	JSONObject iteObject = (JSONObject) ite.get("Item");
    	
    	//recogemos el titiulo
        String titulo = (String) iteObject.get("Titulo");    
        System.out.println("Titulo :"+titulo);
        
        //recogemos el autor
        String autor = (String) iteObject.get("Autor");    
        System.out.println("Autor :"+autor);
        
        //recogemos la fecha
        String fecha = (String) iteObject.get("date");    
        System.out.println("Fecha :"+fecha);
        
        //recogemos el nombre
        String nombre = (String) iteObject.get("Nombre");    
        System.out.println("Nombre :"+nombre);
         
        //recogemos la ciudad
        String ciudad = (String) iteObject.get("Ciudad");  
        System.out.println("Ciudad :"+ciudad);
         
        //recogemos el salario
        String salario = (String) iteObject.get("Salario");    
        System.out.println("Salario :"+salario);
    }
	

}
